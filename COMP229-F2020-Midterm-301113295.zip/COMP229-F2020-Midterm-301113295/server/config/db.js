module.exports = {
    //local MongoDB deployment ->
    //"URI": "mongodb://localhost/books229"
    "URI": "mongodb+srv://aiturgan:0V6OEFYakPxT3blw@mongodbserver.csibw.mongodb.net/book?retryWrites=true&w=majority"
};